import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showappointment',
  templateUrl: './showappointment.component.html',
  styleUrls: ['./showappointment.component.css']
})
export class ShowappointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
